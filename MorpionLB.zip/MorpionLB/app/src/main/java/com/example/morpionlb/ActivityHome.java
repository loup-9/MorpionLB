package com.example.morpionlb;

import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

public class ActivityHome extends AppCompatActivity {
    private long backPressedTime;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
    }

    public void onBackPressed() {

        AlertDialog.Builder builder = new AlertDialog.Builder(ActivityHome.this);
        builder.setMessage("Voulez-vous quitter ?");
        builder.setCancelable(true);
        builder.setNegativeButton("OUI", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                finish();
                finishAffinity();
                //   System.exit(0);
            }
        });

        builder.setPositiveButton("NON", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                dialog.cancel();
            }
        });

        AlertDialog alertDialog = builder.create();
        alertDialog.show();
    }

    public void buttonJouerClick(View view) {
        Intent intent = new Intent(this, MainActivity.class);
        startActivity(intent);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        int id = item.getItemId();

        if (id == R.id.apropos) {
            Intent intent = new Intent(this, AproposActivity.class);
            startActivity(intent);
        } else if (id == R.id.quitter) {
            AlertDialog.Builder builder = new AlertDialog.Builder(ActivityHome.this);
            builder.setMessage("Voulez-vous quitter ?");
            builder.setCancelable(true);
            builder.setNegativeButton("OUI", new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialog, int which) {
                    finish();
                    finishAffinity();
                    // System.exit(0);
                }
            });

            builder.setPositiveButton("NON", new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialog, int which) {
                    dialog.cancel();
                }
            });

            AlertDialog alertDialog = builder.create();
            alertDialog.show();

            //premier essai de sortie propre
           /* Intent AllActivities = new Intent(getApplicationContext(), ActivityHome.class);
            AllActivities.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
            AllActivities.putExtra("EXIT",true);
            finish();
            System.exit(0);*/
        }
        return true;
    }
}