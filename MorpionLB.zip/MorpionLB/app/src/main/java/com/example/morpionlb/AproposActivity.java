package com.example.morpionlb;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

import androidx.appcompat.app.AppCompatActivity;

public class AproposActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_apropos);
    }

    public void buttonRetourClick(View view) {
        Intent intent = new Intent(this, ActivityHome.class);
        startActivity(intent);
    }
}