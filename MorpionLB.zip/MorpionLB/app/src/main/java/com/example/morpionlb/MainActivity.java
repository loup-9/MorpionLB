package com.example.morpionlb;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {
    private Button[][] buttons = new Button[3][3];
    private boolean tourJoueur1 = true;
    private int tourCount;
    private int joueur1Points;
    private int joueur2Points;
    private TextView textViewJoueur1;
    private TextView textViewJoueur2;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        textViewJoueur1 = findViewById(R.id.text_view_joueur1);
        textViewJoueur2 = findViewById(R.id.text_view_joueur2);

        for (int i = 0; i < 3; i++) {
            for (int j = 0; j < 3; j++) {
                String buttonID = "button_" + i + j;
                int resID = getResources().getIdentifier(buttonID, "id", getPackageName());
                buttons[i][j] = findViewById(resID);
                buttons[i][j].setOnClickListener(this);
            }
        }
        Button buttonRAZ = findViewById(R.id.button_RAZ);
        buttonRAZ.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                FirebaseDatabase database = FirebaseDatabase.getInstance();
                DatabaseReference myRef = database.getReference("message");

                resetPartie();
            }
        });
    }
    @Override
    public void onClick(View v) {

        if (!((Button) v).getText().toString().equals("")) {
            return;
        }
        if (tourJoueur1) {
            ((Button) v).setText("X");
        } else {
            ((Button) v).setText("O");
        }
        tourCount++;
        if (verifierVictoire()) {
            if (tourJoueur1) {
                joueur1Gagne();
            } else {
                joueur2Gagne();
            }
        } else if (tourCount == 9) {
            egalite();
        } else {
            tourJoueur1 = !tourJoueur1;
        }
    }
    private boolean verifierVictoire() {
        String[][] field = new String[3][3];
        for (int i = 0; i < 3; i++) {
            for (int j = 0; j < 3; j++) {
                field[i][j] = buttons[i][j].getText().toString();
            }
        }
        for (int i = 0; i < 3; i++) {
            if (field[i][0].equals(field[i][1])
                    && field[i][0].equals(field[i][2])
                    && !field[i][0].equals("")) {
                return true;
            }
        }
        for (int i = 0; i < 3; i++) {
            if (field[0][i].equals(field[1][i])
                    && field[0][i].equals(field[2][i])
                    && !field[0][i].equals("")) {
                return true;
            }
        }
        if (field[0][0].equals(field[1][1])
                && field[0][0].equals(field[2][2])
                && !field[0][0].equals("")) {
            return true;
        }
        if (field[0][2].equals(field[1][1])
                && field[0][2].equals(field[2][0])
                && !field[0][2].equals("")) {
            return true;
        }
        return false;
    }
    private void joueur1Gagne() {
        joueur1Points++;
        Toast.makeText(this, "Joueur 1 gagne!", Toast.LENGTH_SHORT).show();
        updatePointsText();
        resetGame();
    }
    private void joueur2Gagne() {
        joueur2Points++;
        Toast.makeText(this, "Joueur 2 gagne!", Toast.LENGTH_SHORT).show();
        updatePointsText();
        resetGame();
    }
    private void egalite() {
        Toast.makeText(this, "Egalité!", Toast.LENGTH_SHORT).show();
        resetGame();
    }

    private void updatePointsText() {
        textViewJoueur1.setText("Joueur 1: " + joueur1Points);
        textViewJoueur2.setText("Joueur 2: " + joueur2Points);
    }

    private void resetGame() {
        for (int i = 0; i < 3; i++) {
            for (int j = 0; j < 3; j++) {
                buttons[i][j].setText("");
            }
            tourCount = 0;
            tourJoueur1 = true;
        }
    }

    private void resetPartie(){
        joueur1Points = 0;
        joueur2Points = 0;
        updatePointsText();
        resetGame();
    }

    @Override
    protected void onSaveInstanceState(@NonNull Bundle outState) {
        super.onSaveInstanceState(outState);

        outState.putInt("tourCount", tourCount);
        outState.putInt("joueur1Points", joueur1Points);
        outState.putInt("joueur2Points", joueur2Points);
        outState.putBoolean("tourJoueur1", tourJoueur1);
    }

    @Override
    protected void onRestoreInstanceState(@NonNull Bundle savedInstanceState) {
        super.onRestoreInstanceState(savedInstanceState);

        tourCount = savedInstanceState.getInt("tourCount");
        joueur1Points = savedInstanceState.getInt("joueur1Points");
        joueur2Points = savedInstanceState.getInt("joueur2Points");
        tourJoueur1 = savedInstanceState.getBoolean("tourJoueur1");
    }
    public void buttonHomeClick(View view) {
        Intent intent = new Intent (this, ActivityHome.class);
        startActivity(intent);

    }

}