package com.example.morpionlb;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

public class AproposActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_apropos);
    }

    public void buttonRetourClick(View view) {
        Intent intent = new Intent (this, ActivityHome.class);
        startActivity(intent);
    }
}