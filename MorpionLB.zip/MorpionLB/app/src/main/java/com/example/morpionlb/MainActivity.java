package com.example.morpionlb;

import android.content.Intent;
import android.os.Bundle;
import android.renderscript.Sampler;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.FirebaseApp;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {

    private static final String TAG = "MainActivity";

    final private Button[][] buttons = new Button[3][3];
    private boolean tourJoueur1 = true;
    private int tourCount;
    private int joueur1Points;
    private int joueur2Points;
    private TextView textViewJoueur1;
    private TextView textViewJoueur2;

    public int i =0;
    public int j =0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        textViewJoueur1 = findViewById(R.id.text_view_joueur1);
        textViewJoueur2 = findViewById(R.id.text_view_joueur2);

        for (i = 0; i < 3; i++) {
            for ( j = 0; j < 3; j++) {
                String buttonID = "button_" + i + j;
                int resID = getResources().getIdentifier(buttonID, "id", getPackageName());
                buttons[i][j] = findViewById(resID);
                buttons[i][j].setOnClickListener(this);

                buttons[i][j].setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        FirebaseDatabase database = FirebaseDatabase.getInstance();
                        DatabaseReference ButtonSign = database.getReference(buttonID);

                        if (!((Button) v).getText().toString().equals("")) {
                            return;
                        }
                        if (tourJoueur1) {
                            ((Button) v).setText("X");
                           // ButtonSign.setValue(buttons[i][j].getText().toString());
                            ButtonSign.setValue("X");


                        } else {
                            ((Button) v).setText("O");
                           // ButtonSign.setValue(buttons[i][j].getText().toString());
                            ButtonSign.setValue("O");

                        }
                        tourCount++;
                        if (verifierVictoire()) {
                            if (tourJoueur1) {
                                joueur1Gagne();
                            } else {
                                joueur2Gagne();
                            }
                        } else if (tourCount == 9) {
                            egalite();
                        } else {
                            tourJoueur1 = !tourJoueur1;
                        }
                    }
                });

                FirebaseDatabase database = FirebaseDatabase.getInstance();
                DatabaseReference ButtonSign = database.getReference(buttonID);
                ButtonSign.addValueEventListener(new ValueEventListener() {
                    @Override
                    public void onDataChange( DataSnapshot dataSnapshot) {
                     //   String buttonID = dataSnapshot.getValue(String.class);
                      // buttons[i][j].setText(buttonID);
                    }
                    @Override
                    public void onCancelled( DatabaseError error) {

                    }
                });
            }
        }

        final Button buttonRAZ = findViewById(R.id.button_RAZ);
        buttonRAZ.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                resetPartie();
                FirebaseDatabase database = FirebaseDatabase.getInstance();
                DatabaseReference Raz = database.getReference("messageRAZ");
                Raz.setValue("RAZclicked");

            }
        });
        FirebaseDatabase database = FirebaseDatabase.getInstance();
        DatabaseReference Raz= database.getReference("messageRAZ");
        Raz.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                resetPartie();
            Raz.setValue("0");
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                // Failed to read value
                Log.w("APPX", "Failed to read value.", error.toException());
            }
        });
    }

    @Override
    public void onClick(View v) {
        // on verifie que le bouton ne contient pas deja un X ou un O
        if (!((Button) v).getText().toString().equals("")) {
            return;
        }

        if (tourJoueur1) {
            ((Button) v).setText("X");
        } else {
            ((Button) v).setText("O");
        }
        tourCount++;
        if (verifierVictoire()) {
            if (tourJoueur1) {
                joueur1Gagne();
            } else {
                joueur2Gagne();
            }
        } else if (tourCount == 9) {
            egalite();
        } else {
            tourJoueur1 = !tourJoueur1;
        }
    }

    private boolean verifierVictoire() {
        String[][] field = new String[3][3];
        for (int i = 0; i < 3; i++) {
            for (int j = 0; j < 3; j++) {
                field[i][j] = buttons[i][j].getText().toString();
            }
        }
        for (int i = 0; i < 3; i++) {
            if (field[i][0].equals(field[i][1])
                    && field[i][0].equals(field[i][2])
                    && !field[i][0].equals("")) {
                return true;
            }
        }
        for (int i = 0; i < 3; i++) {
            if (field[0][i].equals(field[1][i])
                    && field[0][i].equals(field[2][i])
                    && !field[0][i].equals("")) {
                return true;
            }
        }
        if (field[0][0].equals(field[1][1])
                && field[0][0].equals(field[2][2])
                && !field[0][0].equals("")) {
            return true;
        }
        if (field[0][2].equals(field[1][1])
                && field[0][2].equals(field[2][0])
                && !field[0][2].equals("")) {
            return true;
        }
        return false;
    }

    private void joueur1Gagne() {
        joueur1Points++;
        Toast.makeText(this, "Joueur 1 gagne!", Toast.LENGTH_SHORT).show();
        updatePointsText();
        resetGame();
    }

    private void joueur2Gagne() {
        joueur2Points++;
        Toast.makeText(this, "Joueur 2 gagne!", Toast.LENGTH_SHORT).show();
        updatePointsText();
        resetGame();
    }

    private void egalite() {
        Toast.makeText(this, "Egalité!", Toast.LENGTH_SHORT).show();
        resetGame();
    }

    private void updatePointsText() {
        textViewJoueur1.setText("Joueur 1: " + joueur1Points);
        textViewJoueur2.setText("Joueur 2: " + joueur2Points);
    }

    private void resetGame() {
        for (int i = 0; i < 3; i++) {
            for (int j = 0; j < 3; j++) {
                buttons[i][j].setText("");
                //mon cerveau ne voulait plus faire de boucle
                FirebaseDatabase database = FirebaseDatabase.getInstance();
                DatabaseReference B00 = database.getReference("button_00");
                DatabaseReference B01 = database.getReference("button_01");
                DatabaseReference B02 = database.getReference("button_02");
                DatabaseReference B10 = database.getReference("button_10");
                DatabaseReference B11 = database.getReference("button_11");
                DatabaseReference B12 = database.getReference("button_12");
                DatabaseReference B20 = database.getReference("button_20");
                DatabaseReference B21 = database.getReference("button_21");
                DatabaseReference B22 = database.getReference("button_22");
                B00.setValue(null);
                B01.setValue(null);
                B02.setValue(null);
                B10.setValue(null);
                B11.setValue(null);
                B12.setValue(null);
                B20.setValue(null);
                B21.setValue(null);
                B22.setValue(null);
            }
            tourCount = 0;
            tourJoueur1 = true;
        }
    }

    private void resetPartie() {
        joueur1Points = 0;
        joueur2Points = 0;
        updatePointsText();
        resetGame();
    }

    @Override
    protected void onSaveInstanceState(@NonNull Bundle outState) {
        super.onSaveInstanceState(outState);

        outState.putInt("tourCount", tourCount);
        outState.putInt("joueur1Points", joueur1Points);
        outState.putInt("joueur2Points", joueur2Points);
        outState.putBoolean("tourJoueur1", tourJoueur1);
    }

    @Override
    protected void onRestoreInstanceState(@NonNull Bundle savedInstanceState) {
        super.onRestoreInstanceState(savedInstanceState);

        tourCount = savedInstanceState.getInt("tourCount");
        joueur1Points = savedInstanceState.getInt("joueur1Points");
        joueur2Points = savedInstanceState.getInt("joueur2Points");
        tourJoueur1 = savedInstanceState.getBoolean("tourJoueur1");
    }

    public void buttonHomeClick(View view) {
        Intent intent = new Intent(this, ActivityHome.class);
        startActivity(intent);

    }

}